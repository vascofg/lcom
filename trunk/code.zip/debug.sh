make
make install
service run /usr/sbin/batalha_naval
