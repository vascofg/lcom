/********************************
 *      INTERFACE FUNCTIONS
 ********************************/
int i_drawMatrix();
int i_sideBar();
int i_drawHit(int x, int y, int hit);
int i_printNumber(int n, int x, int y);
int i_readXY(int *x, int *y);
int menu();
